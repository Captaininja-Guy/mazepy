# import pyvista as pv
# import numpy as np
# from PIL import Image




# plt = pv.Plotter()
# array = np.array(Image.open('mobius.png'))[1:,:,:]
# array[:,-1,:] = array[:, -2, :]
# tex = pv.numpy_to_texture(array)


# u = np.linspace(-np.pi,np.pi,100)
# v = np.linspace(-1,1,100)
# u, v = np.meshgrid(u,v)

# x = (1+v/2*np.cos(u/2))*np.cos(u)
# y = (1+v/2*np.cos(u/2))*np.sin(u)
# z = v/2*np.sin(u/2)

# mobius = pv.StructuredGrid(x, y, z).extract_surface(algorithm='dataset_surface')
# mobius.active_texture_coordinates = np.zeros((mobius.points.shape[0], 2))

# u = np.atan2(y, x)
# rho = np.sqrt(x**2+y**2)
# v = 2*np.sign(z*np.sin(u/2)+(rho-1)*np.cos(u/2))*np.sqrt((rho-1)**2+z**2)

# u = (u/(2*np.pi) + .5).flatten()
# v = ((v+1)/2).flatten()


# mobius.active_texture_coordinates[:,0] = u
# mobius.active_texture_coordinates[:,1] = v

# plt.add_mesh(mobius, texture=tex)
# plt.show()





# theta = np.linspace(0,2*np.pi, 100)
# phi = np.linspace(0,2*np.pi, 100)
# theta, phi = np.meshgrid(theta, phi)

# plt = pv.Plotter()
# R, r = 1, .5
# x = ((R + r*np.cos(theta))*np.cos(phi))
# y = ((R + r*np.cos(theta))*np.sin(phi))
# z = (r*np.sin(theta))
# # rho = np.sqrt(x**2 + y**2)

# torus = pv.StructuredGrid(x, y, z)

# # torus.active_texture_coordinates = np.zeros((torus.points.shape[0], 2))

# # torus.active_texture_coordinates[:, 0] = (.5 + np.atan2(y, x)/(2*np.pi)).ravel()
# # torus.active_texture_coordinates[:, 1] = (.5 + np.atan2(z, rho-1)/(2*np.pi)).ravel()

# plt.add_mesh(torus, color='red')
# plt.show_axes()
# plt.show()





# plt = pv.Plotter()
# mesh = pv.ParametricTorus()
# ringradius = 1

# tex = pv.read_texture('torus.png')

# torus = pv.ParametricTorus()
# torus.active_texture_coordinates = np.zeros((torus.points.shape[0],2))

# x = torus.points[:, 0]
# y = torus.points[:, 1]
# z = torus.points[:, 2]
# rho = np.sqrt(x**2 + y**2)

# torus.active_texture_coordinates[:, 0] = .5 + np.atan2(y, x)/(2*np.pi)
# torus.active_texture_coordinates[:, 1] = .5 + np.atan2(z, rho-ringradius)/(2*np.pi)

# plt.add_mesh(torus, texture=tex)
# plt.show()





# sphere = pv.Sphere(
#     radius=1,
#     theta_resolution=120,
#     phi_resolution=120,
#     start_theta=270.001,
#     end_theta=270,
# )

# # Initialize the texture coordinates array
# sphere.active_texture_coordinates = np.zeros((sphere.points.shape[0], 2))

# # Populate by manually calculating
# sphere.active_texture_coordinates[:, 0] = 0.5 + np.arctan2(-sphere.points[:, 0], sphere.points[:, 1])/(2 * np.pi)
# sphere.active_texture_coordinates[:, 1] = 0.5 + np.arcsin(sphere.points[:, 2]) / np.pi

# # And let's display it with a world map
# tex = pv.read_texture('sphere.png')
# sphere.plot(texture=tex)






# tex = pv.read_texture('Test_Cylinder_left.png')
# tex2 = pv.read_texture('Test_Cylinder_right.png') # Flipped horizontaly


# half = pv.Cube(bounds=(-5, 0,-5,5,-5,5))
# clipped = cyl.clip_surface(half)
# plt.add_mesh(clipped, texture=tex)

# half2 = pv.Cube(bounds=(0, 5,-5,5,-5,5))
# clipped2 = cyl.clip_surface(half2)
# plt.add_mesh(clipped2, texture=tex2)


# plt.show_axes()
# plt.show()





# tex0 = pv.read_texture('Test_cube_face_0.png')
# face0 = pv.Plane(center=(-.5, 0, 0), direction=(-1, 0, 0))

# tex1 = pv.read_texture('Test_cube_face_1.png')
# face1 = pv.Plane(center=(0, -.5, 0), direction=(0, -1, 0))

# tex2 = pv.read_texture('Test_cube_face_2.png')
# face2 = pv.Plane(center=(.5, 0, 0), direction=(1, 0, 0))

# tex3 = pv.read_texture('Test_cube_face_3.png')
# face3 = pv.Plane(center=(0, .5, 0), direction=(0, 1, 0))

# tex4 = pv.read_texture('Test_cube_face_4.png')
# face4 = pv.Plane(center=(0, 0, .5), direction=(0, 0, 1))

# tex5 = pv.read_texture('Test_cube_face_5.png')
# face5 = pv.Plane(center=(0, 0, -.5), direction=(0, 0, -1))

# plt.add_mesh(face0, texture=tex0)
# plt.add_mesh(face1, texture=tex1)
# plt.add_mesh(face2, texture=tex2)
# plt.add_mesh(face3, texture=tex3)
# plt.add_mesh(face4, texture=tex4)
# plt.add_mesh(face5, texture=tex5)